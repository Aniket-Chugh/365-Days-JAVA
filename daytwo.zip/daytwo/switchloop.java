package daytwo;
// switch in java -->
public class switchloop {
   

    public static void main(String[] args) {
        

        int day = 7;

        switch(day){
            case 1: 
            System.out.println("Moday");
            break;
            case 2:
            System.out.println("Tuesday");
            break;
            case 3: 
            System.out.println("Wednesday");
            break;
            case 4: 
            System.out.println("thursday");
            break;
            default:
            System.out.println("invalid !!");
            break;
        }


    }



}
