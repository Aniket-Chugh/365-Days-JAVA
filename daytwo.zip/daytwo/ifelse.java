package daytwo;

public class ifelse {
  public static void main(String[] args){
    int age = 14 ;

    if (age < 18) {
        System.out.println(" you can not vote !!");
    }
    else if (age > 18 ) {
        System.out.println("you can vote ");
    } else {
        System.out.println("you can not vote ");
    }
  }
}
