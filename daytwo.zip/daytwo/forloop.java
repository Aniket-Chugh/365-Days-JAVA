package daytwo;

public class forloop {
    public static void main(String[] args) {
        int n = 2;
        int y;
     
            for(int i = 1; i<=10; i++){
    y = i*n;
    System.out.println(n+ " X " + i + " = " + y);
            }
        
    }
}
