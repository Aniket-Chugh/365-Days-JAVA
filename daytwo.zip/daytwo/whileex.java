package daytwo;

public class whileex {
    public static void main(String[] args) {
        int x = 0;

        while(x == 0){
System.out.println("it worked !");
        }
    }
}
