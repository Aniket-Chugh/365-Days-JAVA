package daytwo;

public class dowhilex {
    public static void main(String[] args) {
        int x = 2;
        do{
            System.out.println("it worked but x is not equal to 3");
        } while(x == 3);
    }
}
